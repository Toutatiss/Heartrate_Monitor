/*******************************************************************************
* File Name: Pin_dig.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Pin_dig_ALIASES_H) /* Pins Pin_dig_ALIASES_H */
#define CY_PINS_Pin_dig_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define Pin_dig_0			(Pin_dig__0__PC)
#define Pin_dig_0_INTR	((uint16)((uint16)0x0001u << Pin_dig__0__SHIFT))

#define Pin_dig_1			(Pin_dig__1__PC)
#define Pin_dig_1_INTR	((uint16)((uint16)0x0001u << Pin_dig__1__SHIFT))

#define Pin_dig_2			(Pin_dig__2__PC)
#define Pin_dig_2_INTR	((uint16)((uint16)0x0001u << Pin_dig__2__SHIFT))

#define Pin_dig_3			(Pin_dig__3__PC)
#define Pin_dig_3_INTR	((uint16)((uint16)0x0001u << Pin_dig__3__SHIFT))

#define Pin_dig_4			(Pin_dig__4__PC)
#define Pin_dig_4_INTR	((uint16)((uint16)0x0001u << Pin_dig__4__SHIFT))

#define Pin_dig_5			(Pin_dig__5__PC)
#define Pin_dig_5_INTR	((uint16)((uint16)0x0001u << Pin_dig__5__SHIFT))

#define Pin_dig_6			(Pin_dig__6__PC)
#define Pin_dig_6_INTR	((uint16)((uint16)0x0001u << Pin_dig__6__SHIFT))

#define Pin_dig_7			(Pin_dig__7__PC)
#define Pin_dig_7_INTR	((uint16)((uint16)0x0001u << Pin_dig__7__SHIFT))

#define Pin_dig_INTR_ALL	 ((uint16)(Pin_dig_0_INTR| Pin_dig_1_INTR| Pin_dig_2_INTR| Pin_dig_3_INTR| Pin_dig_4_INTR| Pin_dig_5_INTR| Pin_dig_6_INTR| Pin_dig_7_INTR))

#endif /* End Pins Pin_dig_ALIASES_H */


/* [] END OF FILE */
