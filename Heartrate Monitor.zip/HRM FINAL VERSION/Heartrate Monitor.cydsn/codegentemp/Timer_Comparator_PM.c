/*******************************************************************************
* File Name: Timer_Comparator_PM.c
* Version 2.80
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "Timer_Comparator.h"

static Timer_Comparator_backupStruct Timer_Comparator_backup;


/*******************************************************************************
* Function Name: Timer_Comparator_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Comparator_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void Timer_Comparator_SaveConfig(void) 
{
    #if (!Timer_Comparator_UsingFixedFunction)
        Timer_Comparator_backup.TimerUdb = Timer_Comparator_ReadCounter();
        Timer_Comparator_backup.InterruptMaskValue = Timer_Comparator_STATUS_MASK;
        #if (Timer_Comparator_UsingHWCaptureCounter)
            Timer_Comparator_backup.TimerCaptureCounter = Timer_Comparator_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!Timer_Comparator_UDB_CONTROL_REG_REMOVED)
            Timer_Comparator_backup.TimerControlRegister = Timer_Comparator_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: Timer_Comparator_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Comparator_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_Comparator_RestoreConfig(void) 
{   
    #if (!Timer_Comparator_UsingFixedFunction)

        Timer_Comparator_WriteCounter(Timer_Comparator_backup.TimerUdb);
        Timer_Comparator_STATUS_MASK =Timer_Comparator_backup.InterruptMaskValue;
        #if (Timer_Comparator_UsingHWCaptureCounter)
            Timer_Comparator_SetCaptureCount(Timer_Comparator_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!Timer_Comparator_UDB_CONTROL_REG_REMOVED)
            Timer_Comparator_WriteControlRegister(Timer_Comparator_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: Timer_Comparator_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Comparator_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void Timer_Comparator_Sleep(void) 
{
    #if(!Timer_Comparator_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(Timer_Comparator_CTRL_ENABLE == (Timer_Comparator_CONTROL & Timer_Comparator_CTRL_ENABLE))
        {
            /* Timer is enabled */
            Timer_Comparator_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            Timer_Comparator_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    Timer_Comparator_Stop();
    Timer_Comparator_SaveConfig();
}


/*******************************************************************************
* Function Name: Timer_Comparator_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Comparator_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_Comparator_Wakeup(void) 
{
    Timer_Comparator_RestoreConfig();
    #if(!Timer_Comparator_UDB_CONTROL_REG_REMOVED)
        if(Timer_Comparator_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                Timer_Comparator_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
