/*******************************************************************************
* File Name: VDAC_ref_hb_PM.c  
* Version 1.90
*
* Description:
*  This file provides the power management source code to API for the
*  VDAC8.  
*
* Note:
*  None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "VDAC_ref_hb.h"

static VDAC_ref_hb_backupStruct VDAC_ref_hb_backup;


/*******************************************************************************
* Function Name: VDAC_ref_hb_SaveConfig
********************************************************************************
* Summary:
*  Save the current user configuration
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
*******************************************************************************/
void VDAC_ref_hb_SaveConfig(void) 
{
    if (!((VDAC_ref_hb_CR1 & VDAC_ref_hb_SRC_MASK) == VDAC_ref_hb_SRC_UDB))
    {
        VDAC_ref_hb_backup.data_value = VDAC_ref_hb_Data;
    }
}


/*******************************************************************************
* Function Name: VDAC_ref_hb_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
*******************************************************************************/
void VDAC_ref_hb_RestoreConfig(void) 
{
    if (!((VDAC_ref_hb_CR1 & VDAC_ref_hb_SRC_MASK) == VDAC_ref_hb_SRC_UDB))
    {
        if((VDAC_ref_hb_Strobe & VDAC_ref_hb_STRB_MASK) == VDAC_ref_hb_STRB_EN)
        {
            VDAC_ref_hb_Strobe &= (uint8)(~VDAC_ref_hb_STRB_MASK);
            VDAC_ref_hb_Data = VDAC_ref_hb_backup.data_value;
            VDAC_ref_hb_Strobe |= VDAC_ref_hb_STRB_EN;
        }
        else
        {
            VDAC_ref_hb_Data = VDAC_ref_hb_backup.data_value;
        }
    }
}


/*******************************************************************************
* Function Name: VDAC_ref_hb_Sleep
********************************************************************************
* Summary:
*  Stop and Save the user configuration
*
* Parameters:  
*  void:  
*
* Return: 
*  void
*
* Global variables:
*  VDAC_ref_hb_backup.enableState:  Is modified depending on the enable 
*  state  of the block before entering sleep mode.
*
*******************************************************************************/
void VDAC_ref_hb_Sleep(void) 
{
    /* Save VDAC8's enable state */    
    if(VDAC_ref_hb_ACT_PWR_EN == (VDAC_ref_hb_PWRMGR & VDAC_ref_hb_ACT_PWR_EN))
    {
        /* VDAC8 is enabled */
        VDAC_ref_hb_backup.enableState = 1u;
    }
    else
    {
        /* VDAC8 is disabled */
        VDAC_ref_hb_backup.enableState = 0u;
    }
    
    VDAC_ref_hb_Stop();
    VDAC_ref_hb_SaveConfig();
}


/*******************************************************************************
* Function Name: VDAC_ref_hb_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  VDAC_ref_hb_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void VDAC_ref_hb_Wakeup(void) 
{
    VDAC_ref_hb_RestoreConfig();
    
    if(VDAC_ref_hb_backup.enableState == 1u)
    {
        /* Enable VDAC8's operation */
        VDAC_ref_hb_Enable();

        /* Restore the data register */
        VDAC_ref_hb_SetValue(VDAC_ref_hb_Data);
    } /* Do nothing if VDAC8 was disabled before */    
}


/* [] END OF FILE */
