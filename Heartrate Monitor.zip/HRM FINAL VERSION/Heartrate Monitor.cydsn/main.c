/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <math.h>

void writeDig();
void writeNum();
void writeWord();
void clearDisplay();
void soundBuzzer();
void buzzTicker();

int current_mode; // 0: sleep, 1: startup, 2: programming group, 3 brightness adjustment, 4 heartrate measuring
int group_number = 1;
int max_group_number = 99;

int32 milli;
int five_mS_Count = 5;
int buzzer = 0;
int time_of_interrupt;


// Variables used for calculating the bpm
float period = 0; // Time between rising edges
float acceptedPeriod = 0;
int numMeasurements = 0;
float averagePeriod;

// test variables used for detected whether sleep mode can be left.

float test_acceptedPeriod = 0;
int test_numMeasurements = 0;
int signalReceivedFlag;
int sleepExit;


int badMeasurements = 0;


float storedTime = 0;
int numReadings = 0;
int maxReadings = 5;
float readingTime;


int heart_rate = 0;
float heart_rate_history[5] = {0,0,0,0,0};
float heart_rate_temp;
int V_LED = 124; // 3.056V (191 / .016)
//int V_LED = 200;
int adcVal;
float adcVoltage;

CY_ISR(TimerComparatorISR)
{   
    time_of_interrupt = milli; // record time of capture
    period = (65536 - Timer_Comparator_ReadCapture()) / 1000.0f + storedTime; // get time between rising edges in seconds
    
    
    // Accepting consecutive measurements
    if ((period < 1.2)&&(period > 0.5)&&(current_mode == 4)) {
        //test_numMeasurements++;
        signalReceivedFlag = 1;
    }// else {
    //    test_numMeasurements = 0;
    //}
    /*
    // Need 3 good measurements before entering measure mode, run only if in sleep mode
    if (current_mode != 4) {
        if (test_numMeasurements > 3) {
            test_numMeasurements = 0;
           
            current_mode = 4;
            sleepExit = 1;
        }
    }
    */
 
    
    // Resetting the timer
    Timer_Reset_Write(1);
    CyDelay(2);
    Timer_Reset_Write(0);
    Timer_Comparator_ReadStatusRegister();
}

CY_ISR(TimerBackgroundISR)
{
    milli++;
    five_mS_Count--;
    if (five_mS_Count == 0) {
        five_mS_Count = 5;
        buzzer--;
    }
    
    if (buzzer == 0) { // turn off buzzer
        Buzz_Pin_Write(1);
    }
}

CY_ISR(ButtonISR0)
{
    // Sound the buzzer for 200ms
    Buzz_Pin_Write(0);
    CyDelay(200);
    Buzz_Pin_Write(1);
    
    switch (current_mode){
        case 0: // SLEEP - If both buttons are held, switch to programming group mode
            CyDelay(10);
            if ((Button_1_Read()==0)&(Button_0_Read()==0)) {
                CyDelay(1000);
                if((Button_1_Read()==0)&(Button_0_Read()==0)){ // Check if both buttons are held down for 1 sec
                    current_mode = 2;
                    group_number--;
                }
            }
            break;
        case 2: // PROGRAMMING GROUP - increment the group number
            group_number++;
            group_number = group_number>max_group_number ? 0 : group_number; // Ensure group number doesn't go over 99
            writeNum(group_number,1);
            break;
        }
}

CY_ISR(ButtonISR1)
{
    Buzz_Pin_Write(0);
    CyDelay(200);
    Buzz_Pin_Write(1);
    switch (current_mode){ // SLEEP - If both buttons are held, switch to programming group mode
        case 0:
            if ((Button_1_Read()==0)&(Button_0_Read()==0)) {
                CyDelay(1000);
                if((Button_1_Read()==0)&(Button_0_Read()==0)) {
                    current_mode = 2;
                    group_number--;
                }
            }
            break;
        case 2: // PROGRAMMING GROUP - decrement the group number
            group_number--;
            group_number = group_number<0 ? max_group_number : group_number; // Ensure group number doesn't go below 0
            writeNum(group_number,1);
            break;
        case 3: // MEASURING - If both buttong are held, switch to programming mode
            if ((Button_1_Read()==0)&(Button_0_Read()==0)) {
                CyDelay(1000);
                if((Button_1_Read()==0)&(Button_0_Read()==0)){
                    current_mode = 2;
                }
            }
            break;    
    }
}

CY_ISR(ButtonISR2)
{
    Buzz_Pin_Write(0);
    CyDelay(200);
    Buzz_Pin_Write(1);
    
    if (current_mode == 2){ // If in programming group mode, go back to sleep
        current_mode = 0;
        EEPROM_WriteByte(group_number, 0);
    }
}

CY_ISR(ButtonISR3) // Does nothing
{
    Buzz_Pin_Write(0);
    CyDelay(200);
    Buzz_Pin_Write(1);
}

CY_ISR(FingerISR)
{
    switch(current_mode){
        case 0: // SLEEP - wake up
            current_mode = 4;
            sleepExit = 1;
            VDAC_ref_finger_SetValue(187);
            break;
        case 4: // HEARTRATE MEASUREMENT - go to sleep
            current_mode = 0;
            VDAC_ref_finger_SetValue(50);
            break;
    }
}

int main(void)
{
    current_mode = 1; // Enable startup mode
    
    // Initialize components
    Timer_Background_Start();
    Timer_Comparator_Start();
    EEPROM_Start();
    Opamp_1_Start();
    Opamp_2_Start();
    Comp_1_Start();
    Comp_finger_Start();
    VDAC_LED_Start();
    VDAC_ref_finger_Start();
    VDAC_ref_hb_Start();
    
    ADC_SAR_1_Start();
    ADC_SAR_1_StartConvert();
    
    // Enable interrupts
    
    CyGlobalIntEnable;
    button_0_isr_ClearPending();
    button_1_isr_ClearPending();
    button_2_isr_ClearPending();
    button_3_isr_ClearPending();
    timer_background_isr_ClearPending();
    timer_comparator_isr_ClearPending();
    finger_isr_ClearPending();
    
    button_0_isr_StartEx(ButtonISR0);
    button_1_isr_StartEx(ButtonISR1);
    button_2_isr_StartEx(ButtonISR2);
    button_3_isr_StartEx(ButtonISR3);    
    timer_background_isr_StartEx(TimerBackgroundISR);
    timer_comparator_isr_StartEx(TimerComparatorISR);
    

    
    // Load variables from EEPROM
    
    group_number = EEPROM_ReadByte(0);
    
    // TESTING
    
    /*uint8 adcResult;
    float adcVolts;
    char tmpStr[15];

    for(int i=0;i<100;i++)			//Get 100 samples
    {
        if(ADC_SAR_1_IsEndConversion(ADC_SAR_1_RETURN_STATUS)!=0)   	//Has it finished current conversion
        {                                              		 			
            adcResult = ADC_SAR_1_GetResult8();               			//Yes so get 8 bit result
            adcVolts = ADC_SAR_1_CountsTo_Volts(adcResult);   		 //Convert to volts for display
            sprintf(tmpStr, "%1.1fV ", adcVolts); 	 	            		//Create text string
            UART_1_PutString(tmpStr);                  		 	    	//Print string to console
            CyDelay(5);                                          		  		//Delay 5mS (200 samples/S)
            UART_1_WriteTxData(0x20);                   		   		//Place a space between characters
            
        }
    }*/

    // END TESTING
    
    // Light up all LEDs on each digit with a 1 second delay between digits
    
    for (int i=1; i<5; i++){
        writeDig(i,8,0);
        CyDelay(1000);
        writeDig(i,12,1);
    }
        
    /*
    // Check each number works
    
    for (int i=0; i<10; i++){
        writeDig(1,i,1);
        writeDig(2,i,1);
        writeDig(3,i,1);
        writeDig(4,i,1);
        CyDelay(1000);
    }
    clearDisplay();
    */
    
    // Display group number
    writeNum(group_number,1);
    CyDelay(1000);
    clearDisplay();

    current_mode = 0; // go to sleep
    VDAC_LED_SetValue(V_LED); // no calibration
    CyDelay(2000);
    finger_isr_ClearPending();
    finger_isr_StartEx(FingerISR);
    
    
    
            
    for (;;){ // main loop
        switch(current_mode){
            case 0: // SLEEP - blink the LED and a dp - TODO blink LED

                buzzTicker(1);
                CyDelay(800);

                break;
            case 2: // PROGRAMMING GROUP - flash the group number
                writeNum(group_number,1);
                CyDelay(1000);
                clearDisplay();
                CyDelay(500);
                break;
            case 3: // BRIGHTNESS ADJUSTMENT - if the light recieved is too bright, dim the LED
                /*if(ADC_SAR_1_IsEndConversion(ADC_SAR_1_RETURN_STATUS)!=0) { // Check if conversion is finished
                    // Find the current voltage of the IR reciever
                    adcVal = ADC_SAR_1_GetResult8();
                    adcVoltage = ADC_SAR_1_CountsTo_Volts(adcVal);
                    
                    // If the voltage is too high, dim the LED
                    if (adcVoltage > 3){
                        V_LED--;
                        VDAC_LED_SetValue(V_LED);
                    } else { // Otherwise, begin reading the user's heart rate
                        writeWord(1); // Write rEAd to screen
                        CyDelay(2000);
                        current_mode = 4;
                    }
                }*/
                CyDelay(25);
                break;
            case 4: // HEARTRATE MEASUREMENT
                
                if (sleepExit == 1) {
                    writeWord(0);
                    CyDelay(2000);
                    clearDisplay();
                    CyDelay(3000);
                    sleepExit = 0;
                }
                
                if (signalReceivedFlag == 1) {
                    // Check first if the period is valid, currently set to between 50bpm and 120bpm
                    if ((period < 1.2)&&(period > 0.5)) {
                        acceptedPeriod += period;
                        numMeasurements++;
                    } else {
                        numMeasurements = 0;
                    }
                    
                    
                    period = 0; // reset period so that it will not be reused
                    if (numMeasurements !=0) {
                        averagePeriod = acceptedPeriod/numMeasurements;                
                        heart_rate = round(60/averagePeriod);
                        
                        if (numMeasurements > 3) {
                            buzzTicker(2);
                            writeNum(heart_rate,1);
                            CyDelay(1500);
                            clearDisplay();
                            CyDelay(4500);
                            
                            
                            // Refresh calculation to improve accuracy
                            acceptedPeriod = averagePeriod;
                            numMeasurements = 1;
                            averagePeriod = 0;
                        }

                        
                        signalReceivedFlag = 0;
                    }
                }
                
                
                // After 3 bad measurements or 5 seconds of no measurements, go to sleep
                    if (milli - time_of_interrupt > 8000) {
                        current_mode = 0;
                    }
                
                
                break;
                
        }
    }
}

void writeNum(int num, int isFull) // Writes a <=4 digit number to the LED screen
{ 
    // Working out each digit
    int num1 = num % 10;
    num -= num1;
    int num2 = (num % 100)/10;
    num -= num2;
    int num3 = (num % 1000)/100;
    num -= num3;
    int num4 = (num % 10000)/1000;
    
    // TODO - Make this not show leading 0s
    
    // Writing them to screen
    writeDig(1,num4,1);
    writeDig(2,num3,isFull);
    writeDig(3,num2,1);
    writeDig(4,num1,1);
}

void writeWord(int word)
{
    switch (word) {
        case 0: // CALC
            writeDig(1, 17, 0);
            writeDig(2, 15, 0);
            writeDig(3, 18, 0);
            writeDig(4, 17, 0);
            break;
        case 1: // rEAd
            writeDig(1, 13, 0);
            writeDig(2, 14, 0);
            writeDig(3, 15, 0);
            writeDig(4, 16, 0);
            break;
    }
}


void writeDig(int pos, int num, int dp) // Light up a digit
{
    // Array determining which pins to light up dependent on the given number
    uint8 num_to_pin[19] = {
        0x02, // 00000010 0
        0x9E, // 10011110 1
        0x24, // 00100100 2
        0x0c, // 00001100 3
        0x98, // 10011000 4
        0x48, // 01001000 5
        0x40, // 01000000 6
        0x1E, // 00011110 7
        0x00, // 00000000 8
        0x08, // 00001000 9
        0x62, // 01100010 C - 10
        0xD4, // 11010100 n - 11
        0xFE, // 11111110   - 12
        0xF5, // 11110101 r - 13
        0x61, // 01100001 E - 14
        0x11, // 00010001 A - 15
        0x85, // 10000101 d - 16
        0x63, // 01100011 C - 17
        0xE3  // 11100011 L - 18
    };
    
    uint8 val = num_to_pin[num]+dp;
    
    // Writing to the digit selector pins
    switch (pos) {
        case 1:
            Dig_1_Write(val);
            break;
        case 2:
            Dig_2_Write(val);
            break;
        case 3:
            Dig_3_Write(val);
            break;
        case 4:
            Dig_4_Write(val);
            break;
    }
}

void clearDisplay() // Clears the display
{
    writeDig(1,12,1);
    writeDig(2,12,1);
    writeDig(3,12,1);
    writeDig(4,12,1);
}

void soundBuzzer(int duration) // Sounds the buzzer for a given duration in ms
{
    Buzz_Pin_Write(0);
    CyDelay(duration);
    Buzz_Pin_Write(1);
}

void buzzTicker(int numTicks)
{
    for (int i = 0; i < numTicks; i++ ) {
        Buzz_Pin_Write(0);
        CyDelay(10);
        Buzz_Pin_Write(1);
        if (i != numTicks) {
            CyDelay(200);
        }
    }
    
}

/* [] END OF FILE */
