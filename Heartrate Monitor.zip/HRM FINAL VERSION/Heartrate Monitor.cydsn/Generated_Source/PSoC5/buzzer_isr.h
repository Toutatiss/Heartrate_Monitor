/*******************************************************************************
* File Name: buzzer_isr.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_buzzer_isr_H)
#define CY_ISR_buzzer_isr_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void buzzer_isr_Start(void);
void buzzer_isr_StartEx(cyisraddress address);
void buzzer_isr_Stop(void);

CY_ISR_PROTO(buzzer_isr_Interrupt);

void buzzer_isr_SetVector(cyisraddress address);
cyisraddress buzzer_isr_GetVector(void);

void buzzer_isr_SetPriority(uint8 priority);
uint8 buzzer_isr_GetPriority(void);

void buzzer_isr_Enable(void);
uint8 buzzer_isr_GetState(void);
void buzzer_isr_Disable(void);

void buzzer_isr_SetPending(void);
void buzzer_isr_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the buzzer_isr ISR. */
#define buzzer_isr_INTC_VECTOR            ((reg32 *) buzzer_isr__INTC_VECT)

/* Address of the buzzer_isr ISR priority. */
#define buzzer_isr_INTC_PRIOR             ((reg8 *) buzzer_isr__INTC_PRIOR_REG)

/* Priority of the buzzer_isr interrupt. */
#define buzzer_isr_INTC_PRIOR_NUMBER      buzzer_isr__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable buzzer_isr interrupt. */
#define buzzer_isr_INTC_SET_EN            ((reg32 *) buzzer_isr__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the buzzer_isr interrupt. */
#define buzzer_isr_INTC_CLR_EN            ((reg32 *) buzzer_isr__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the buzzer_isr interrupt state to pending. */
#define buzzer_isr_INTC_SET_PD            ((reg32 *) buzzer_isr__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the buzzer_isr interrupt. */
#define buzzer_isr_INTC_CLR_PD            ((reg32 *) buzzer_isr__INTC_CLR_PD_REG)


#endif /* CY_ISR_buzzer_isr_H */


/* [] END OF FILE */
